const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());


const readData = () => JSON.parse(fs.readFileSync('db.json'));
const writeData = (data) => fs.writeFileSync('db.json', JSON.stringify(data, null, 2));

// API REST
app.get('/api/sensori', (req, res) => {
    const sensori = readData();
    res.json(sensori);
});

app.post('/api/sensori', (req, res) => {
    const sensori = readData();
    const { matricola, zona, lettura } = req.body;

    if (!matricola || !zona || lettura == null) {
        return res.status(400).json({ error: 'Campi obbligatori mancanti' });
    }

    if (matricola.length !== 8 || zona.length > 30 || lettura > 100) {
        return res.status(400).json({ error: 'Dati non validi' });
    }

    const nuovoSensore = { id: sensori.length + 1, matricola, zona, lettura };
    sensori.push(nuovoSensore);
    writeData(sensori);
    res.status(201).json(nuovoSensore);
});

app.use(express.static('public'));

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
