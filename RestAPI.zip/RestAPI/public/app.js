const apiUrl = 'http://localhost:3000/api/sensori';


const fetchSensori = async () => {
    const res = await fetch(apiUrl);
    const sensori = await res.json();

    const list = document.getElementById('sensorList');
    list.innerHTML = '';
    sensori.forEach(s => {
        const item = document.createElement('li');
        item.textContent = `${s.matricola} - ${s.zona} - ${s.lettura}`;
        list.appendChild(item);
    });
};

fetchSensori();
